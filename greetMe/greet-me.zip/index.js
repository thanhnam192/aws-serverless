const moment = require('moment');

const greetings = {
    'en': 'hello',
    'vn': 'xin chao',
    'fr': 'Franco'
};


exports.handler = async (event) => {
    const name = event.pathParameters.name;
    let {lang,...info} = event.queryStringParameters;

    const greeting = greetings[lang] ? greetings[lang] : greetings['en'];
    const message = `${greeting} ${name}`;
    const response = {
        message,
        info
    };

    return {
        'statusCode' : 200,
        'body': JSON.stringify(response)
    };

}